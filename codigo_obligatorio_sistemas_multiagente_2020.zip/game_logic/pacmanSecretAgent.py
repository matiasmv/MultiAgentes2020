from game import Agent

class PacmanSecretAgent(Agent):
    def getAction(self, state):
        pass